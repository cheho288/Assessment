// spec.js
describe('Backbase Assessment App', function() {
  var FindCompName = element(by.id('searchbox'));
  var FilterNameButton = element(by.id('searchsubmit'));

  beforeEach(function() {
    browser.waitForAngularEnabled(false);
    browser.get('http://computer-database.herokuapp.com/computers');
  });

  it('should have a title', function() {
    expect(browser.getTitle()).toEqual('Computers database');
  });

  it('should Delete computer Che', function() {
    FindCompName.sendKeys('Che');

    FilterNameButton.click();

    var ResultText = element.all(by.cssContainingText('td', 'Che')).get(0).getText();    

    expect(ResultText).toMatch('Che');

    var Link = element(by.cssContainingText('a', 'Che')).getAttribute('href')   

    Link.click();

    var DeleteBTN = element(by.css('[value="Delete this computer"]'));
    DeleteBTN.click();

    var DeleteText = element.all(by.cssContainingText('strong', 'Done!')).get(0).getText(); 
    
    expect(DeleteText).toMatch('Done!');

    // browser.driver.sleep(5000);
  });
});