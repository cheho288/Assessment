// spec.js
describe('Backbase Assessment App', function() {
  var AddCompBtn = element(by.id('add'));

  beforeEach(function() {
    browser.waitForAngularEnabled(false);
    browser.get('http://computer-database.herokuapp.com/computers');
  });

  it('should have a title', function() {
    expect(browser.getTitle()).toEqual('Computers database');
  });

  it('should add a new computer Che', function() {
    
    AddCompBtn.click()

    var CompName = element(by.id('name'));
    CompName.sendKeys('Che');

    var Intro = element(by.id('introduced'));
    Intro.sendKeys('2018-03-17');   

    var DisCont = element(by.id('discontinued'));
    DisCont.sendKeys('2020-03-17');   

    var CompDrop = element(by.id('company'));
    CompDrop.$('[value="22"').click()    

    var CreateBTN = element(by.css('[value="Create this computer"]'));
    CreateBTN.click();

    var ResultText = element.all(by.cssContainingText('strong', 'Done!')).get(0).getText(); 
    
    expect(ResultText).toMatch('Done!');

    // browser.driver.sleep(5000);
  });
});