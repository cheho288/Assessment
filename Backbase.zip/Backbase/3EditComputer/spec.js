// spec.js
describe('Backbase Assessment App', function() {
  var FindCompName = element(by.id('searchbox'));
  var FilterNameButton = element(by.id('searchsubmit'));

  beforeEach(function() {
    browser.waitForAngularEnabled(false);
    browser.get('http://computer-database.herokuapp.com/computers');
  });

  it('should have a title', function() {
    expect(browser.getTitle()).toEqual('Computers database');
  });

  it('should Edit computer Che', function() {
    FindCompName.sendKeys('Che');

    FilterNameButton.click();

    var ResultText = element.all(by.cssContainingText('td', 'Che')).get(0).getText();    

    expect(ResultText).toMatch('Che');

    var Link = element(by.cssContainingText('a', 'Che')).getAttribute('href')   

    Link.click();

    var CompName = element(by.id('name'));
    CompName.sendKeys(' - changed');

    var CompDrop = element(by.id('company'));
    CompDrop.$('[value="24"').click()    

    var SaveBTN = element(by.css('[value="Save this computer"]'));
    SaveBTN.click();

    var SaveText = element.all(by.cssContainingText('strong', 'Done!')).get(0).getText(); 
    
    expect(SaveText).toMatch('Done!');

    // browser.driver.sleep(5000);
  });
});