// spec.js
describe('Backbase Assessment App', function() {
  var FindCompName = element(by.id('searchbox'));
  var FilterNameButton = element(by.id('searchsubmit'));

  beforeEach(function() {
    browser.waitForAngularEnabled(false);
    browser.get('http://computer-database.herokuapp.com/computers');
  });

  it('should have a title', function() {
    expect(browser.getTitle()).toEqual('Computers database');
  });

  it('should find computer APEXC', function() {
    FindCompName.sendKeys('APEXC');

    FilterNameButton.click();

    var ResultText = element.all(by.cssContainingText('td', 'APEXC')).get(0).getText();    

    expect(ResultText).toMatch('APEXC');

    //browser.driver.sleep(5000);
  });
});